# Platform Kernel Update 01

Genesis 7.2 introduces the Platform Kernel.

## Files

- `aletheus/platform_kernel/kernel.py`
- `aletheus/platform_kernel/__init__.py`

## Purpose

The Platform Kernel coordinates:

- Executive Kernel
- Runtime Adapter
- Capability Host

It does not modify `runtime/core.py`.

## Verification

```bash
python -m py_compile \
  aletheus/platform_kernel/__init__.py \
  aletheus/platform_kernel/kernel.py
```
